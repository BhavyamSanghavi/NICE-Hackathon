package com.nice.coday;


import org.apache.poi.ss.formula.eval.NotImplementedException;

import java.io.IOException;

public class ElectricityConsumptionCalculatorImpl implements ElectricityConsumptionCalculator {
    @Override
    public ConsumptionResult calculateElectricityAndTimeConsumption(ResourceInfo resourceInfo) throws IOException {
        // Your implementation will go here
        throw new NotImplementedException("Not implemented yet.");
    }
}
